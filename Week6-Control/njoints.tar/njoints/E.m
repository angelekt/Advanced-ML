function E1=E(theta,theta_0,nu,T,t,x_target,y_target,alpha,deltat)

klad1=theta(1)-theta_0(1);
if (klad1>pi), klad1=klad1-pi;end;
if (klad1<-pi), klad1=klad1+pi;end;
klad2=theta(2)-theta_0(2);
if (klad2>pi), klad2=klad2-pi;end;
if (klad2<-pi), klad2=klad2+pi;end;
E1=0.5*(klad1^2+klad2^2)/nu/(T-t+deltat)+ phi(theta,x_target,y_target,alpha)/nu;
%E1=phi(theta,x_target,y_target,alpha)/nu;
