clear all
n=3;
T=2;
dt=0.05;
dt1=dt/10;
dt2=dt1/10;
alpha=100;
Nsamples=2000;
METHOD='exact';
METHOD='MF';

rand('state',0)
randn('state',0)

deltat=0.0;


nu=0.5;

targetsize=sqrt(nu/alpha);


x_target=n/sqrt(2);
y_target=n/sqrt(2);
x_target=0;y_target=0;
%x_target=n/2;
%y_target=n/2;

DEMO='demo2';

switch DEMO
case 'demo1',
	n=3;
	x_target=0;y_target=0;
	figsize=n;
	theta=pi/4*ones(1,n);
case 'demo2'
	n=10;
	x_target=n/2;
	y_target=n/2;
	figsize=1.5*n/2;
	theta=randn(1,n);
end;	
	


figure(2)
clf


taulist=[dt:dt:T-dt, T-dt+dt1:dt1:T-dt1, T-dt1+dt2:dt2:T-dt2];
tauold=0;
i_tau=0;
u_all=zeros(length(taulist),n);
x_all=zeros(length(taulist),n);
y_all=zeros(length(taulist),n);
theta_all=zeros(length(taulist),n);
av_theta_all=zeros(length(taulist),n);
for tau=taulist,
	i_tau=i_tau+1;
	dt=tau-tauold
	%compute av_theta
	sigma_nu=sqrt(nu*(T-tau+deltat));
	sigma_MH=0.5;
	switch METHOD,
	case 'importance',
		for j=1:Nsamples,
			theta1=theta+sigma_nu*randn(1,n);
			theta2(j,:)=theta1;
			phi1(j)=phi(theta1,x_target,y_target,alpha);
		end;
		w=exp(-phi1/nu);
		av_theta=w*theta2;
		av_theta=av_theta/sum(w);
	case 'MH',
		if (tau==dt),
			theta2(1,:)=theta;
		else
			theta2(1,:)=av_theta;
		end;
		accept=1;
		for j=2:Nsamples,
			theta1=theta2(j-1,:)+sigma_MH*randn(1,n);
			E_old=E(theta2(j-1,:),theta,nu,T,tau,x_target,y_target,alpha,deltat);
			E_new=E(theta1,theta,nu,T,tau,x_target,y_target,alpha,deltat);
			dE=E_new-E_old;
			if (rand<exp(-dE)),
				theta2(j,:)=theta1;
				accept=accept+1;
			else
				theta2(j,:)=theta2(j-1,:);
			end;
		end;
		av_theta=mean(theta2,1);
		accept	
		figure(1)
		clf
		plot(theta2(:,1),theta2(:,2),'.',theta(1),theta(2),'*r',av_theta(1),av_theta(2),'*g')
		hold on
		%file2
		hold off
	case 'MF',
		% mu, sigma are the means and cov. of var. distr. q=prod_i q_i, q_i\propto
		% \exp (-(theta-mu_i)/2/sigma_i)
		eta=0.001/n;
		if (tau==dt),
            mu=theta+sigma_MH*randn(1,n);
            mu=theta;
			sigma=nu*T*ones(1,n);
        end;
		delta=1;
		while (delta>0.001),
			x_n=cos(mu)*exp(-sigma'/2); % mean end point
			y_n=sin(mu)*exp(-sigma'/2); % mean end point
			dmu=theta+alpha*(T-tau+deltat)*(sin(mu).*exp(-sigma/2)*(x_n-x_target)-cos(mu).*exp(-sigma/2)*(y_n-y_target))-mu;
			dsigma=nu*(1/(T-tau+deltat)+alpha*exp(-sigma)-alpha*(x_n-x_target)*cos(mu).*exp(-sigma/2)-alpha*(y_n-y_target)*sin(mu).*exp(-sigma/2)).^(-1)-sigma;
			delta=max(abs(dmu),abs(dsigma));
			mu=mu+eta*dmu;
			sigma=sigma+eta*dsigma;
		end;
		av_theta=mu;
		%figure(4)
		%clf
		%plot(theta(1),theta(2),'*r',av_theta(1),av_theta(2),'*g')
		%hold on
		%line([av_theta(1)-sqrt(sigma(1)),av_theta(1)+sqrt(sigma(1))],[av_theta(2),av_theta(2)])
		%line([av_theta(1),av_theta(1)],[av_theta(2)-sqrt(sigma(2)),av_theta(2)+sqrt(sigma(2))])
		%file2
		%hold off
	case 'exact'
		figure(3)
		clf
		file2
		p=exp(-C);
		Psi=sum(sum(p));
		p=p/Psi;
		av_theta=[sum(sum(X.*p)),sum(sum(Y.*p))]
		hold on
		plot(theta(1),theta(2),'*r',av_theta(1),av_theta(2),'*g')
		hold off
	end;
	u=(av_theta-theta)/(T-tau+deltat);
	u_all(i_tau,:)=u;
	dtheta=u*dt+ sqrt(nu*dt)*randn(1,n);
	theta=theta+dtheta;
	figure(5)
	clf
	[x y]=carth(theta);
	line([0 x(1)],[0,y(1)])
	hold on
	plot(x(1),y(1),'.r')
	for j=2:n,
    	line([x(j-1) x(j)], [y(j-1) y(j)])
		plot(x(j),y(j),'.r')
	end;
	switch METHOD,
	case 'MF',
		[x_av y_av]=av_carth(mu,sigma);
		l1=line([0 x_av(1)],[0,y_av(1)]);
		set(l1,'LineStyle',':');
		plot(x_av(1),y_av(1),'.r')
		for j=2:n,
    		l1=line([x_av(j-1) x_av(j)], [y_av(j-1) y_av(j)]);
			set(l1,'LineStyle',':');
			plot(x_av(j),y_av(j),'.r')
		end;
	end;
	axis([-figsize figsize -figsize figsize])
	hold on
	circle(x_target,y_target,targetsize,'.k')
	hold off
	figure(2)
	subplot(2,2,2)
	plot(av_theta(1),av_theta(2),'.k',theta(1),theta(2),'.r')
	hold on
	axis([-pi pi -pi pi])
	subplot(2,2,3)
	plot(tau,sqrt(u*u'),'.r',tau,sqrt(nu/T),'.k')
	hold on
	drawnow
	tauold=tau;
	theta_all(i_tau,:)=mod(theta,2*pi);
	av_theta_all(i_tau,:)=mod(av_theta,2*pi);
	x_all(i_tau,:)=x;
	y_all(i_tau,:)=y;
	pause
end;
for i=1:0,
	dtheta=u*dt+ sqrt(nu*dt)*randn(1,n);
	theta=theta+dtheta;
	figure(2)
subplot(2,2,1)
    [x y]=carth(theta);
    line([0 x(1)],[0,y(1)])
    for j=2:n,
        line([x(j-1) x(j)], [y(j-1) y(j)])
    end;
    axis([-n n -n n])
    hold on
    plot(x_target,y_target,'.k')
    hold off
end
figure
subplot(2,3,1)
plot(u_all)
subplot(2,3,2)
plot(x_all)
subplot(2,3,3)
plot(y_all)
subplot(2,3,4)
plot(av_theta_all)
subplot(2,3,5)
plot(theta_all)
