%contour plot in 2 d case


N=100;
dtheta=2*pi/50;
for i=1:50,
for j=1:50,
	theta3=[-pi+(i-1)*dtheta,-pi+(j-1)*dtheta];
	X(i,j)=theta3(1);
	Y(i,j)=theta3(2);
	C(i,j)=E(theta3,theta,nu,T,tau,x_target,y_target,alpha,deltat);
end;
end;
contour(X,Y,C)
colorbar
axis([-pi pi -pi pi])

