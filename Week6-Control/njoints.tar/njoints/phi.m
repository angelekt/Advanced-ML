function phi1=phi(theta,x_target,y_target,alpha)
n=length(theta);
% x(0)=y(0)=0 
x(1)=cos(theta(1));
y(1)=sin(theta(1));
for j=2:n,
	x(j)=x(j-1)+cos(theta(j));
	y(j)=y(j-1)+sin(theta(j));
end;
phi1=0.5*alpha*((x(n)-x_target)^2+(y(n)-y_target)^2);
