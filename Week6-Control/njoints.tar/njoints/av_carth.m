function [x1 y1]=av_carth(mu,sigma);
n=length(mu);
% x(0)=y(0)=0 
x1(1)=cos(mu(1))*exp(-sigma(1)/2);
y1(1)=sin(mu(1))*exp(-sigma(1)/2);
for j=2:n,
	x1(j)=x1(j-1)+cos(mu(j))*exp(-sigma(j)/2);
	y1(j)=y1(j-1)+sin(mu(j))*exp(-sigma(j)/2);
end;
