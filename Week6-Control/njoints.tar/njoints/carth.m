function [x1 y1]=carth(theta)
n=length(theta);
% x(0)=y(0)=0 
x1(1)=cos(theta(1));
y1(1)=sin(theta(1));
for j=2:n,
	x1(j)=x1(j-1)+cos(theta(j));
	y1(j)=y1(j-1)+sin(theta(j));
end;
